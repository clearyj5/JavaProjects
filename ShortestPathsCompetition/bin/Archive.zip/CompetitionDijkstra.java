/*
 * A Contest to Meet (ACM) is a reality TV contest that sets three contestants at three random
 * city intersections. In order to win, the three contestants need all to meet at any intersection
 * of the city as fast as possible.
 * It should be clear that the contestants may arrive at the intersections at different times, in
 * which case, the first to arrive can wait until the others arrive.
 * From an estimated walking speed for each one of the three contestants, ACM wants to determine the
 * minimum time that a live TV broadcast should last to cover their journey regardless of the contestantsâ€™
 * initial positions and the intersection they finally meet. You are hired to help ACM answer this question.
 * You may assume the following:
 *    ï‚· Each contestant walks at a given estimated speed.
 *    ï‚· The city is a collection of intersections in which some pairs are connected by one-way
 * streets that the contestants can use to traverse the city.
 *
 * This class implements the competition using Dijkstra's algorithm
 */
/**
 * @author: Jack Cleary - 19333982
 * @version: 04/04/2021
 */
import java.io.*;
import java.util.*;

public class CompetitionDijkstra {

    public String inputFile;
    public int sA;
    public int sB;
    public int sC;
    public double distanceTo[][];
    public int edgeTo[][];
    public int edge;
    public int infinity = Integer.MAX_VALUE;

    /**
     * @param filename: A filename containing the details of the city road network
     * @param sA,       sB, sC: speeds for 3 contestants
     */
    CompetitionDijkstra(String filename, int sA, int sB, int sC) {

        this.sA = sA;
        this.sB = sB;
        this.sC = sC;
        this.inputFile = filename;


        try {

                File inputFile = new File(filename);
                Scanner readInput = new Scanner(inputFile);
                int lineIndex = 0;

                while (readInput.hasNextLine()) {

                    String[] line = readInput.nextLine().trim().split("\\s+");

                    if (lineIndex == 0) {

                        distanceTo = new double[Integer.parseInt(line[lineIndex])][Integer.parseInt(line[lineIndex])];
                        edgeTo = new int[Integer.parseInt(line[lineIndex])][Integer.parseInt(line[lineIndex])];


                        for (int j = 0; j < distanceTo.length; j++) {

                            for (int k = 0; k < distanceTo[j].length; k++) {

                                distanceTo[j][k] = infinity;

                                if (j == k) {

                                    distanceTo[j][k] = 0;

                                }
                            }
                        }
                    } else if (lineIndex == 1) {

                        edge = Integer.parseInt(line[lineIndex - 1]);

                    } else {

                        distanceTo[Integer.parseInt(line[0])][Integer.parseInt(line[1])] = Double.parseDouble(line[2]);
                        edgeTo[Integer.parseInt(line[0])][Integer.parseInt(line[1])] = Integer.parseInt(line[0]);

                    }
                    lineIndex++;
                }

                for (int j = 0; j < distanceTo.length; j++) {
                    dijkstraShortestPath(j);
                }

                readInput.close();

        } catch(FileNotFoundException | OutOfMemoryError | NullPointerException e){

        	System.out.println("\n\n This is an invalid input. Sorry I cannot process this request.");
            distanceTo = new double[0][0];
            edgeTo = new int[0][0];
        }
    }



    public void dijkstraShortestPath(int k){

        boolean[] checkIfPathIsShortest = new boolean[distanceTo.length];

        checkIfPathIsShortest[k] = true;

        while (true){

            int x = -1;

            for (int i = 0; i < distanceTo.length; i++){

                if ((!checkIfPathIsShortest[i]) && distanceTo[k][i] != infinity){

                    x = i;
                    break;
                }
            }

            if (x == -1){

                return;
            }

            checkIfPathIsShortest[x] = true;

            for (int i = 0; i < distanceTo.length; i++){

                if (distanceTo[k][x] + distanceTo[x][i] < distanceTo[k][i]){

                    distanceTo[k][i] = distanceTo[k][x] + distanceTo[x][i];

                    checkIfPathIsShortest[i] = false;
                    edgeTo[k][i] = x;

                }
            }
        }

    }


    /**
     * @return int: minimum minutes that will pass before the three contestants can meet
     */
    public int timeRequiredforCompetition() {


    	double minimumSpeed = Math.min((Math.min(this.sA, this.sB)), this.sC);
        double maxSpeed = (Math.max(Math.max(sA, sB), sC));
    	if (maxSpeed > 100 || minimumSpeed < 50) return -1;


        double maximumDistance = 0.00;

        for (double[] doubles : distanceTo) {

            for (int j = 0; j < doubles.length; j++) {

                if (doubles[j] > maximumDistance) {

                    maximumDistance = doubles[j];
                }

            }
        }
        double maxDistanceInMeters = maximumDistance*1000;

        int maxTimeRequired = (int) Math.ceil((maxDistanceInMeters)/minimumSpeed);

        if (maximumDistance == 0){
            return -1;

        }
        if (maxTimeRequired == infinity) {
			return -1;
		}
        
        return maxTimeRequired;
    }

}



