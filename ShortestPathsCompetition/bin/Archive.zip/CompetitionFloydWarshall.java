import java.util.*;
import java.io.*;

/*
 * A Contest to Meet (ACM) is a reality TV contest that sets three contestants at three random
 * city intersections. In order to win, the three contestants need all to meet at any intersection
 * of the city as fast as possible.
 * It should be clear that the contestants may arrive at the intersections at different times, in
 * which case, the first to arrive can wait until the others arrive.
 * From an estimated walking speed for each one of the three contestants, ACM wants to determine the
 * minimum time that a live TV broadcast should last to cover their journey regardless of the contestants
 * initial positions and the intersection they finally meet. You are hired to help ACM answer this question.
 * You may assume the following:
 *    ï‚· Each contestant walks at a given estimated speed.
 *    ï‚· The city is a collection of intersections in which some pairs are connected by one-way
 * streets that the contestants can use to traverse the city.
 *
 * This class implements the competition using Floyd-Warshall algorithm
 */

/**
 * @author Jack Cleary - 19333982 	
 * @version 04/04/2021 
 * 
 */



public class CompetitionFloydWarshall {

	private static final double INFINITY = Integer.MAX_VALUE / 3;

	String filename;
	int sA, sB, sC;

	double intersections[][];

	int slowestContestant;
	int numberOfIntersections;
	int numberOfStreets;

	boolean invalidFile = false;

	/**
	 * @param filename: A filename containing the details of the city road network
	 * @param sA,       sB, sC: speeds for 3 contestants
	 */
	CompetitionFloydWarshall(String filename, int sA, int sB, int sC) {

		// TODO
		this.filename = filename;

		this.sA = sA;
		this.sB = sB;
		this.sC = sC;

		this.fileReader();
		this.getSlowestContestant();

	}

	private void fileReader() {

		try {

			BufferedReader bReader = new BufferedReader(new FileReader(filename));

			numberOfIntersections = Integer.parseInt(bReader.readLine());
			numberOfStreets = Integer.parseInt(bReader.readLine());

			if (numberOfIntersections == 0 | numberOfStreets == 0) {
				invalidFile = true;
			}

			else {

				intersections = new double[numberOfIntersections][numberOfIntersections];

				for (int i = 0; i < numberOfIntersections; i++) {
					for (int j = 0; j < numberOfIntersections; j++) {
						intersections[i][j] = INFINITY;
					}
				}

				String lineFromFile;

				while ((lineFromFile = bReader.readLine()) != null) {
					String[] splitValues = lineFromFile.split(" ");
					intersections[Integer.parseInt(splitValues[0])][Integer.parseInt(splitValues[1])] = Double
							.parseDouble(splitValues[2]);
				}
				bReader.close();
			}
		} catch (Exception e) {
			invalidFile = true;
		}

	}

	public int getSlowestContestant() {

		if (sA < sB && sA < sC) {
			slowestContestant = sA;
		}

		else if (sB < sA && sB < sC) {
			slowestContestant = sB;
		}

		else {
			slowestContestant = sC;
		}

		return slowestContestant;
	}

	/**
	 * @return int: minimum minutes that will pass before the three contestants can
	 *         meet
	 */
	public int timeRequiredforCompetition() {

		// TO DO
		if ((sA > 100 || sA < 50) || (sB > 100 || sB < 50) || (sC > 100 || sC < 50)) {
			return -1;
		}

		if (invalidFile) {
			return -1;
		}

		for (int k = 0; k < numberOfIntersections; k++) {
			for (int i = 0; i < numberOfIntersections; i++) {
				for (int j = 0; j < numberOfIntersections; j++) {
					if (intersections[i][k] + intersections[k][j] < intersections[i][j]) {
						intersections[i][j] = intersections[i][k] + intersections[k][j];
					}
				}
			}
		}

		double longestDistance = getLongestDistance();

		if (longestDistance == INFINITY) {
			return -1;
		}

		return (int) Math.ceil((longestDistance * 1000) / slowestContestant);
	}

	private double getLongestDistance() {

		double longestDistance = -1;

		for (int i = 0; i < numberOfIntersections; i++) {
			for (int j = 0; j < numberOfIntersections; j++) {

				longestDistance = (intersections[i][j] > longestDistance && i != j) ? intersections[i][j]
						: longestDistance;
			}

		}

		return longestDistance;
	}
}