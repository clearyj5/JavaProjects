import static org.junit.Assert.*;
import org.junit.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.IOException;

/**
* @author Jack Cleary - 19333982 	
* @version 04/04/2021 
*/

public class CompetitionTests {

	@Test
	public void testDijkstraConstructor() {

		String filename = "tinyEWD.txt";
		
		int sA = 65;
		int sB = 86;
		int sC = 50;
		CompetitionDijkstra map = new CompetitionDijkstra(filename, sA, sB, sC);
		assertEquals(38, map.timeRequiredforCompetition());
		
	}
	
	@Test
	public void testFWConstructor() {

		String filename = "tinyEWD.txt";
		
		int sA = 50;
		int sB = 86;
		int sC = 65;
		CompetitionFloydWarshall map;
		try {
			map = new CompetitionFloydWarshall(filename, sA, sB, sC);
			assertEquals(38, map.timeRequiredforCompetition());
			
		} catch (OutOfMemoryError | NullPointerException e) {}	
	}

	@Test
	public void testDijkstraFilenameError() {
		String filename = "incorrect.txt";
		
		int sA = 50;
		int sB = 86;
		int sC = 65;
			CompetitionDijkstra map = new CompetitionDijkstra(filename, sA, sB, sC);
	}
	

	@Test
	public void testFWFilenameError() 
	{
		String filename = "incorrect.txt";
		
		int sA = 50;
		int sB = 86;
		int sC = 65;
		
		CompetitionFloydWarshall map = new CompetitionFloydWarshall(filename, sA, sB, sC);
	}

	@Test
	public void testDijkstraNegativeSpeed()
	{

		String filename = "tinyEWD.txt";
		
		int sA = 0;
		int sB = 86;
		int sC = 65;
		
		CompetitionDijkstra map = new CompetitionDijkstra(filename, sA, sB, sC);
		assertEquals(-1, map.timeRequiredforCompetition());
		
		sA = -1;
		sB = 0;
		sC = -2;
		map = new CompetitionDijkstra(filename, sA, sB, sC);
		assertEquals(-1, map.timeRequiredforCompetition());
	}

	@Test
	public void testFWNegativeSpeed() 
	{
		String filename = "tinyEWD.txt";
		int sA = 0;
		int sB = 86;
		int sC = 65;
		try {
			CompetitionFloydWarshall map = new CompetitionFloydWarshall(filename, sA, sB, sC);
			assertEquals(-1, map.timeRequiredforCompetition());
			
			sA = -1;
			sB = 0;
			sC = -2;
			map = new CompetitionFloydWarshall(filename, sA, sB, sC);
			assertEquals(-1, map.timeRequiredforCompetition());
			
		} catch (OutOfMemoryError | NullPointerException e) {}
	}

	@Test
	public void testInputA() 
	{
		
		String filename = "input-A.txt";
		
		int sA = 75;
		int sB = 95;
		int sC = 60;
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		} catch (OutOfMemoryError | NullPointerException e) {}
	}

	@Test
	public void testInputB() 
	{
		String filename = "input-B.txt";
		
		int sA = 75;
		int sB = 95;
		int sC = 60;
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		} catch (OutOfMemoryError | NullPointerException e) {}
	}

	@Test
	public void testInputC() 
	{
		String filename = "input-C.txt";
		
		int sA = 75;
		int sB = 95;
		int sC = 60;
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		} catch (OutOfMemoryError | NullPointerException e) {}
	}

	@Test
	public void testInputD() 
	{
		String filename = "input-D.txt";
		
		int sA = 75;
		int sB = 95;
		int sC = 60;
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		} catch (OutOfMemoryError | NullPointerException e) {}
	}

	@Test
	public void testInputE() throws IOException
	{
		String filename = "input-E.txt";
		
		int sA = 75;
		int sB = 95;
		int sC = 60;
		
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		} catch (OutOfMemoryError | NullPointerException e) {}
	}

	@Test
	public void testInputF() 
	{
		String filename = "input-F.txt";
		
		int sA = 75;
		int sB = 95;
		int sC = 60;
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		} catch (OutOfMemoryError | NullPointerException e) {}
	}

	@Test
	public void testInputG() 
	{
		String filename = "input-G.txt";
		
		int sA = 75;
		int sB = 95;
		int sC = 60;
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		} catch (OutOfMemoryError | NullPointerException e) {}
	}

	
	@Test
	public void testInputH()
	{
		String filename = "input-H.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		} catch (OutOfMemoryError | NullPointerException e) {}
	}

	@Test
	public void testInputI() 
	{
		String filename = "input-I.txt";
		
		int sA = 75;
		int sB = 95;
		int sC = 60;
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		} catch (OutOfMemoryError | NullPointerException e) {}
	}

	@Test
	public void testInputJ() 
	{
		String filename = "input-J.txt";
		
		int sA = 75;
		int sB = 95;
		int sC = 60;
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
			
			assertEquals(-1, mapD.timeRequiredforCompetition());
			assertEquals(-1, mapFW.timeRequiredforCompetition());
			
		} catch (OutOfMemoryError | NullPointerException e) {}
	
		
	}

	@Test
	public void testInputK() 
	{
		String filename = "input-K.txt";
		
		int sA = 75;
		int sB = 95;
		int sC = 60;
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		} catch (OutOfMemoryError | NullPointerException e) {}
	}

	@Test
	public void testInputL() 
	{
		String filename = "input-L.txt";
		
		int sA = 75;
		int sB = 95;
		int sC = 60;
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		} catch (OutOfMemoryError | NullPointerException e) {}
	}
	
	@Test
	public void testInputM() 
	{
		String filename = "input-M.txt";
		
		int sA = 75;
		int sB = 95;
		int sC = 60;
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		} catch (OutOfMemoryError | NullPointerException e) {}
	}

	@Test
	public void testInputN()
	{
		String filename = "input-N.txt";
		
		int sA = 75;
		int sB = 95;
		int sC = 60;
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		} catch (OutOfMemoryError | NullPointerException e) {}
	}

	@Test
	public void testEWD() 
	{
		String filename = "1000EWD.txt";
		
		int sA = 75;
		int sB = 95;
		int sC = 60;
		
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		} catch (OutOfMemoryError | NullPointerException e) {}
	} 
	
	@Test
	public void testExceptionalSpeeds()
	{
		String filename = "tinyEWD.txt";
		
		int sA = 10;
		int sB = 200;
		int sC = 60;
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
			
			assertEquals(-1, mapD.timeRequiredforCompetition());
			assertEquals(-1, mapFW.timeRequiredforCompetition());
			
		} catch (OutOfMemoryError | NullPointerException e) {}
	}
	
	@Test
	public void testExtras() 
	{
		String filename = "input-A.txt";
		
		int sA = 50;
		int sB = 50;
		int sC = 50;
		
		
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		
		assertEquals(-1, mapD.timeRequiredforCompetition());
		assertEquals(-1, mapFW.timeRequiredforCompetition());
		
		filename = "tinyEWD.txt";
		
		sA = 65;
		sB = 55;
		sC = 70;
		
		mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		
		filename = "input-A.txt";
		
		sA = 60;
		sB = 50;
		sC = 75;
		
		mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		
		assertEquals(-1, mapD.timeRequiredforCompetition());
		assertEquals(-1, mapFW.timeRequiredforCompetition());
		
		
	}
	
	@Test
	public void testExceptionalSpeeds2()
	{
		String filename = "tinyEWD.txt";
		
		int sA = 10;
		int sB = 10;
		int sC = 10;
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
			
			assertEquals(-1, mapD.timeRequiredforCompetition());
			assertEquals(-1, mapFW.timeRequiredforCompetition());
			
		} catch (OutOfMemoryError | NullPointerException e) {}
	}
	
	@Test
	public void testExceptionalSpeeds3()
	{
		String filename = "tinyEWD.txt";
		
		int sA = 200;
		int sB = 200;
		int sC = 200;
		try{
			CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
			CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
			
			assertEquals(-1, mapD.timeRequiredforCompetition());
			assertEquals(-1, mapFW.timeRequiredforCompetition());
			
		} catch (OutOfMemoryError | NullPointerException e) {}
	}
	
}