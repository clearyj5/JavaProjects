import static org.junit.Assert.*;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;

/* 
* @author Will O'Callaghan - 19334234  	
* @version 04/04/2021 
*/

public class CompetitionTests {

	@Test
	public void testDijkstraConstructor() throws FileNotFoundException {

		String filename = "tinyEWD.txt";
		
		int sA = 60;
		int sB = 80;
		int sC = 50;
		CompetitionDijkstra map = new CompetitionDijkstra(filename, sA, sB, sC);
		assertEquals(38, map.timeRequiredforCompetition());
		
	}
	
	@Test
	public void testFWConstructor() throws FileNotFoundException {

		String filename = "tinyEWD.txt";
		
		int sA = 50;
		int sB = 80;
		int sC = 60;
		CompetitionFloydWarshall map = new CompetitionFloydWarshall(filename, sA, sB, sC);
		assertEquals(38, map.timeRequiredforCompetition());
		
	}

	@Test
	public void testDijkstraFilenameError() throws FileNotFoundException
	{
		String filename = "incorrect.txt";
		
		int sA = 50;
		int sB = 80;
		int sC = 60;
		CompetitionDijkstra map = new CompetitionDijkstra(filename, sA, sB, sC);
	}

	@Test
	public void testFWFilenameError() throws FileNotFoundException
	{
		String filename = "incorrect.txt";
		
		int sA = 50;
		int sB = 80;
		int sC = 60;
		CompetitionFloydWarshall map = new CompetitionFloydWarshall(filename, sA, sB, sC);

	}

	@Test
	public void testDijkstraNegativeSpeed() throws FileNotFoundException
	{

		String filename = "tinyEWD.txt";
		
		int sA = 0;
		int sB = 80;
		int sC = 60;
		CompetitionDijkstra map = new CompetitionDijkstra(filename, sA, sB, sC);
		assertEquals(-1, map.timeRequiredforCompetition());
		
		sA = -1;
		sB = 0;
		sC = -2;
		map = new CompetitionDijkstra(filename, sA, sB, sC);
		assertEquals(-1, map.timeRequiredforCompetition());
	}

	@Test
	public void testFWNegativeSpeed() throws FileNotFoundException
	{
		String filename = "tinyEWD.txt";
		int sA = 0;
		int sB = 80;
		int sC = 60;
		CompetitionFloydWarshall map = new CompetitionFloydWarshall(filename, sA, sB, sC);
		assertEquals(-1, map.timeRequiredforCompetition());
		
		sA = -1;
		sB = 0;
		sC = -2;
		map = new CompetitionFloydWarshall(filename, sA, sB, sC);
		assertEquals(-1, map.timeRequiredforCompetition());
	}

	@Test
	public void testInputA() throws FileNotFoundException
	{
		
		String filename = "input-A.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
	}

	@Test
	public void testInputB() throws FileNotFoundException
	{
		String filename = "input-B.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);

	}

	@Test
	public void testInputC() throws FileNotFoundException
	{
		String filename = "input-C.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
	}

	@Test
	public void testInputD() throws FileNotFoundException
	{
		String filename = "input-D.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
	}
/*
	@Test
	public void testInputE()
	{
		String filename = "input-E.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);	
	}
*/
	@Test
	public void testInputF() throws FileNotFoundException
	{
		String filename = "input-F.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);	
	}

	@Test
	public void testInputG() throws FileNotFoundException
	{
		String filename = "input-G.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
	}

	/*@Test
	public void testInputH()
	{
		String filename = "input-H.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
	}*/

	@Test
	public void testInputI() throws FileNotFoundException
	{
		String filename = "input-I.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
	}

	@Test
	public void testInputJ() throws FileNotFoundException
	{
		String filename = "input-J.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
		
		assertEquals(-1, mapD.timeRequiredforCompetition());
		assertEquals(-1, mapFW.timeRequiredforCompetition());
	}

	@Test
	public void testInputK() throws FileNotFoundException
	{
		String filename = "input-K.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);	
		
	}

	@Test
	public void testInputL() throws FileNotFoundException
	{
		String filename = "input-L.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
	}

	@Test
	public void testInputM() throws FileNotFoundException
	{
		String filename = "input-M.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);
	}

	@Test
	public void testInputN() throws FileNotFoundException
	{
		String filename = "input-N.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);	
		
	}   

	@Test
	public void testEWD() throws FileNotFoundException
	{
		String filename = "1000EWD.txt";
		
		int sA = 70;
		int sB = 90;
		int sC = 60;
		CompetitionDijkstra mapD = new CompetitionDijkstra(filename, sA, sB, sC);
		CompetitionFloydWarshall mapFW = new CompetitionFloydWarshall(filename, sA, sB, sC);	
		
	}   
	
}