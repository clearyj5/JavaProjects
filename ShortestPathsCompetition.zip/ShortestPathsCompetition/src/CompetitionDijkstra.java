import java.util.*;
import java.io.*;

/*
 * A Contest to Meet (ACM) is a reality TV contest that sets three contestants at three random
 * city intersections. In order to win, the three contestants need all to meet at any intersection
 * of the city as fast as possible.
 * It should be clear that the contestants may arrive at the intersections at different times, in
 * which case, the first to arrive can wait until the others arrive.
 * From an estimated walking speed for each one of the three contestants, ACM wants to determine the
 * minimum time that a live TV broadcast should last to cover their journey regardless of the contestantsâ€™
 * initial positions and the intersection they finally meet. You are hired to help ACM answer this question.
 * You may assume the following:
 *    ï‚· Each contestant walks at a given estimated speed.
 *    ï‚· The city is a collection of intersections in which some pairs are connected by one-way
 * streets that the contestants can use to traverse the city.
 *
 * This class implements the competition using Dijkstra's algorithm
 */

/**
 * @author Jack Cleary
 */

public class CompetitionDijkstra {

	public int sA;
	public int sB;
	public int sC; //Speeds of contestants A, B & C
	
	public int I; //Number of Nodes (Intersections)
	public int S; //Number of edges (Streets)
	
	public Graph city; //Graph of the city as Adjacency List
	
	public class Graph {
		Set<Node> intersections;
		
		Graph() {
			this.intersections = new HashSet<Node>();
		}
		
		public void editNode(Node a, Node b, double dist){

            //Find Node object for v1 and add new destination
            for(Node node : intersections){
                if(node.number == a.number){
                    //Update existing node with a new destination 
                    node.addDestination(b, dist);
                    return;
                }
            }
        }
		
		public boolean contains(Node a) {

            for(Node node : intersections){
                if(node.number == a.number)
                    return true;
            }
            return false;
        }  
		
		public Node getNode(int nodeID){
	        
	        Iterator<Node> iter = this.intersections.iterator();

	        while (iter.hasNext()) {
	            
	            Node node = iter.next();
	            
	            if(node.number == nodeID)
	                return node;
	        }
	        return null;
	    }
	}
	
	public class Node {
		public int number; //intersection number
		public List<Node> shortestPath; //Last node visited on shortest path
		public double distance; //shortest distance from source
		public Map<Node, Double> adjNodes; //Set of the adjacent Nodes and their weights
		
		Node (int number) {
			this.number = number;
			this.shortestPath = new LinkedList<Node>();
			this.distance = Double.MAX_VALUE;
			this.adjNodes = new HashMap<Node, Double>();
		}
		
		public void addDestination(Node destination, double distance) {
            this.adjNodes.put(destination, distance);
        }
	}
	
	
    /**
     * @param filename: A filename containing the details of the city road network
     * @param sA, sB, sC: speeds for 3 contestants
    */
	
	//@throws FileNotFoundException 
    CompetitionDijkstra (String filename, int sA, int sB, int sC) throws FileNotFoundException{
    	
    	this.sA = sA;
    	this.sB = sB;
    	this.sC = sC;
    	
    	this.city = new Graph();
    	
    	Scanner file = new Scanner(new File(filename));

        //Read total number of vertices and edges
	    this.I = file.nextInt();
	    this.S = file.nextInt();
	    
	    while(file.hasNext()){
	
	        //Read in node info from text file
	        int i1 = file.nextInt();
	        int i2 = file.nextInt();
	        double distance = file.nextDouble();
	
	        //Create nodes for i1 and i2
	        Node a = new Node(i1);
	        Node b = new Node(i2);
	
	        //Link two nodes with respective distance
	        a.addDestination(b, distance);
	        
	        //If graph already contains nodeA, update it with new distances
            if(city.contains(a)){
            	
                //If b is already a member node, pass actual node of B
                if(city.contains(b)){

                    Node actualB = city.getNode(b.number);
                    city.editNode(a, actualB, distance);
                }

                //If b doesn't already exist, pass new b
                else
                    city.editNode(a, b, distance);
            }

            //Otherwise just add it to graph
            else{
                a.addDestination(b, distance);
                city.intersections.add(a);
            }

            //If graph doesn't already contain v2, add it
            if(!city.contains(b))
                city.intersections.add(b);
	    }
    }
    
    /**
    * @return int: minimum minutes that will pass before the three contestants can meet
     */
    public int timeRequiredforCompetition() {

    	double slowestSpeed = (Math.min(Math.min(sA, sB), sC));
    	double maxSpeed = (Math.max(Math.max(sA, sB), sC));
    	if (maxSpeed > 100 || slowestSpeed < 50) return -1;

        double longestTime = 0.0;
        double longestDistance = 0;
        double time = 0;
        Graph tempGraph;

        //Iterate over every node within the graph
        Iterator<Node> iter = city.intersections.iterator();

        while (iter.hasNext()) {
            Node node = iter.next();

            //Set the node as the source with the graph, re-adjust distances using Dijkstras
            tempGraph = calculateShortestPathFromSource(city, node.number);
            
            Iterator<Node> iter2 = city.intersections.iterator();
            
            while (iter2.hasNext()) {

                Node temp = iter2.next();

                if(temp.distance > longestDistance)
                    longestDistance = temp.distance;
            }
            
            time = (longestDistance * 1000)/slowestSpeed;

            if(time > longestTime)
                longestTime = time;
        }
        
        int intValue = (int) Math.round(longestTime);
        
        return intValue;
    }
    
    public Graph calculateShortestPathFromSource(Graph graph, int sourceID) {
        
        Graph tempGraph = graph;
        Node source = tempGraph.getNode(sourceID);

        //Set source nodes distance from source to 0
        source.distance = 0;
     
        Set<Node> settledNodes = new HashSet<>();
        Set<Node> unsettledNodes = new HashSet<>();
     
        //System.out.println("Source Node = " + source.name);

        //Add source to unsettled nodes i.e examine first
        unsettledNodes.add(source);
        //System.out.println("Added node " + source.name + " to unsettledNodes...\n");

        while (unsettledNodes.size() != 0) {
            
            //Get node with lowest distance from source and examine that first
            Node currentNode = getLowestDistanceNode(unsettledNodes);
            
            //Remove it from unsettled as we will now settle it
            removeNode(currentNode, unsettledNodes);
            
            //Iterate over all of currentNodes adjacent nodes
            for (Map.Entry<Node, Double> adjacencyPair: currentNode.adjNodes.entrySet()) {
                
                Node adjacentNode = adjacencyPair.getKey();
                double edgeWeight = adjacencyPair.getValue();
                //System.out.println("Adjacent node selected is Node " + adjacentNode.name + "(edgeWight of " + edgeWeight + ")");


                //If the adjacent node hasn't already been settled
                if (!alreadySettled(adjacentNode, settledNodes)) {

                    //System.out.println("Node " + adjacentNode.name + " has not been settled, running tests...\n");
                    //System.out.println("\n--------------------------------------------");
                    
                    //Find min dist from current node to adjacent node
                    calculateMinimumDistance(adjacentNode, edgeWeight, currentNode);

                    //System.out.println("Adding Node " + adjacentNode.name + " to unsettledNodes queue...\n");
                    unsettledNodes.add(adjacentNode);
                }
            }
            settledNodes.add(currentNode);

        }
        return tempGraph;

    }
    	
    public Node getLowestDistanceNode(Set <Node> unsettledNodes) {
        
        //Start with empty node and Double.MaxVal
        Node lowestDistanceNode = null;
        double lowestDistance = Double.MAX_VALUE;
        
        /** Iterate over all current unsettled nodes and return the one with lowest 
         * distance from the source node
         */
        for (Node node: unsettledNodes) {
            
            Node properNodeElement = city.getNode(node.number);
            double nodeDistance = properNodeElement.distance;
            
            if (nodeDistance < lowestDistance) {
                lowestDistance = nodeDistance;
                lowestDistanceNode = city.getNode(node.number);
            }
        }
        
        return lowestDistanceNode;
    }

    public static void removeNode(Node nodeToRemove, Set<Node> unsettledNodes){

        Iterator<Node> iter = unsettledNodes.iterator();

        while (iter.hasNext()) {
            Node node = iter.next();

            if (node.number == nodeToRemove.number)
                iter.remove();
        }
    }

    public void calculateMinimumDistance(Node evaluationNode, double length, Node sourceNode) {
        
        Node actualSourceNode = city.getNode(sourceNode.number);
        double sourceDistance = actualSourceNode.distance;
        Node actualEvaluationNode = city.getNode(evaluationNode.number);
        
        //If newly explored path is quicker than current known path, overwrite
        if (sourceDistance + length < actualEvaluationNode.distance) {
            
        	actualEvaluationNode.distance = length;

            LinkedList<Node> newShortestPath = new LinkedList<>(actualSourceNode.shortestPath);
            
            newShortestPath.add(actualSourceNode);
            
            actualEvaluationNode.shortestPath = newShortestPath;
        }
	}
    
    private static boolean alreadySettled(Node testNode, Set<Node> settledNodes){

        for(Node node : settledNodes){
            if(node.number == testNode.number)
                return true;
        }
        return false;

    }
    
    public static void main(String args[]) throws FileNotFoundException {
    	String filename = "tinyEWD.txt";
    	
    	CompetitionDijkstra tinyEWD = new CompetitionDijkstra(filename, 57, 76, 64);
    	
    	System.out.println(tinyEWD.timeRequiredforCompetition());
    }
    
}
